#  Secure Password Generator
# using Python · secrets module · CLI
"""
CLI tool to generate cryptographically secure passwords with configurable length and character sets. Used Python's secrets module instead of random — a deliberate choice for actual security"""

import secrets
import string

def generate_password(length=12):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(secrets.choice(characters) for _ in range(length))
    return password

password = generate_password(12)
print("Your password:", password)