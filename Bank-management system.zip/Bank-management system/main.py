import json
import os

class Account:
    def __init__(self, name, account_number, balance=0):
        self.name = name
        self.account_number = account_number
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount
        print(f"Deposited {amount}. New balance: {self.balance}")

    def withdraw(self, amount):
        if amount > self.balance:
            print("Not enough balance.")
        else:
            self.balance -= amount
            print(f"Withdrew {amount}. New balance: {self.balance}")

    def check_balance(self):
        print(f"Balance: {self.balance}")

    def to_dict(self):
        return {
            "name": self.name,
            "account_number": self.account_number,
            "balance": self.balance
        }


class Bank:
    def __init__(self):
        self.accounts = {}
        self.file = "accounts.json"
        self.load()

    def load(self):
        if os.path.exists(self.file):
            with open(self.file, "r") as f:
                data = json.load(f)
                for acc_num, info in data.items():
                    self.accounts[acc_num] = Account(info["name"], acc_num, info["balance"])

    def save(self):
        with open(self.file, "w") as f:
            data = {acc_num: acc.to_dict() for acc_num, acc in self.accounts.items()}
            json.dump(data, f)

    def create_account(self, name, account_number):
        if account_number in self.accounts:
            print("Account number already exists.")
        else:
            self.accounts[account_number] = Account(name, account_number)
            self.save()
            print(f"Account created for {name} with number {account_number}.")

    def get_account(self, account_number):
        return self.accounts.get(account_number, None)


def main():
    bank = Bank()

    while True:
        print("\n--- Bank Menu ---")
        print("1. Create Account")
        print("2. Deposit")
        print("3. Withdraw")
        print("4. Check Balance")
        print("5. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            name = input("Enter name: ")
            acc_num = input("Enter account number: ")
            bank.create_account(name, acc_num)

        elif choice == "2":
            acc_num = input("Enter account number: ")
            account = bank.get_account(acc_num)
            if account:
                amount = float(input("Enter amount to deposit: "))
                account.deposit(amount)
                bank.save()
            else:
                print("Account not found.")

        elif choice == "3":
            acc_num = input("Enter account number: ")
            account = bank.get_account(acc_num)
            if account:
                amount = float(input("Enter amount to withdraw: "))
                account.withdraw(amount)
                bank.save()
            else:
                print("Account not found.")

        elif choice == "4":
            acc_num = input("Enter account number: ")
            account = bank.get_account(acc_num)
            if account:
                account.check_balance()
            else:
                print("Account not found.")

        elif choice == "5":
            print("Goodbye!")
            break

        else:
            print("Invalid option. Try again.")


main()